package com.example.omnia.androidsignerrest;

public class SignerRequest {
    public String DeviceGUID;
    public String MobileNo;
    public String OTP;

    public SignerRequest(String deviceGUID, String mobileNo, String OTP) {
        DeviceGUID = deviceGUID;
        MobileNo = mobileNo;
        this.OTP = OTP;
    }

    public String getDeviceGUID() {
        return DeviceGUID;
    }

    public void setDeviceGUID(String deviceGUID) {
        DeviceGUID = deviceGUID;
    }

    public String getMobileNo() {
        return MobileNo;
    }

    public void setMobileNo(String mobileNo) {
        MobileNo = mobileNo;
    }

    public String getOTP() {
        return OTP;
    }

    public void setOTP(String OTP) {
        this.OTP = OTP;
    }
}
