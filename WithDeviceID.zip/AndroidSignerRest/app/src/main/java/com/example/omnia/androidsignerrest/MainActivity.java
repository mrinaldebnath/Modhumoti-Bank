package com.example.omnia.androidsignerrest;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    EditText phoneNumber;
    MainActivity m;
    String m_deviceId;
    String m_wlanMacAdd;
    TelephonyManager TelephonyMgr;
    WifiManager m_wm;
    MainActivity main;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        main = this;

        TelephonyMgr = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        m_wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);

        int MY_PERMISSIONS_READ_PHONE_STATE=0;
// Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission((Activity)this,
                Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity)this,
                    Manifest.permission.READ_PHONE_STATE)) {

                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions((Activity)this,
                        new String[]{Manifest.permission.READ_PHONE_STATE},
                        MY_PERMISSIONS_READ_PHONE_STATE);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }

        m_deviceId = TelephonyMgr.getDeviceId();
        m_wlanMacAdd = m_wm.getConnectionInfo().getMacAddress();

        phoneNumber = (EditText) findViewById(R.id.phonenumber);
        //phoneNumber.setShowSoftInputOnFocus(false);

        Button requestOTP=(Button) findViewById(R.id.requestotp);
        m=this;

//        HitRestAsynchronous c=new HitRestAsynchronous("1",m);
//        c.execute();


        requestOTP.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button

//                TelephonyManager TelephonyMgr = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
//                if (ActivityCompat.checkSelfPermission(main, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
//                    // TODO: Consider calling
//                    //    ActivityCompat#requestPermissions
//                    // here to request the missing permissions, and then overriding
//                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
//                    //                                          int[] grantResults)
//                    // to handle the case where the user grants the permission. See the documentation
//                    // for ActivityCompat#requestPermissions for more details.
//                    return;
//                }
//                m_deviceId = TelephonyMgr.getDeviceId();
//
//
//                WifiManager m_wm = (WifiManager)getApplicationContext().getSystemService(Context.WIFI_SERVICE);
//                m_wlanMacAdd = m_wm.getConnectionInfo().getMacAddress();

                String phoneNumberText=phoneNumber.getText().toString();
                phoneNumber.setText("device_id: "+m_deviceId+" mac_id "+m_wlanMacAdd);
                try
                {
                    int phoneNumbrInt=Integer.parseInt(phoneNumberText);
                    HitRestAsynchronous c=new HitRestAsynchronous(phoneNumberText,m_deviceId,m_wlanMacAdd,m);
                    c.execute();
                }
                catch (Exception e)
                {
                    phoneNumber.setText("Entered text is not a phone number");
                }
            }
        });

        phoneNumber.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // Code here executes on main thread after user presses button
                if(phoneNumber.getText().toString().startsWith("Enter"))phoneNumber.setText("");
            }
        });

    }

    public void putErrorMessageOnScreen(String message)
    {
        //phoneNumber.setText(message);
        Log.e("error: ",message);
    }


}
