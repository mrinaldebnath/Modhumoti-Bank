package com.example.omnia.androidsignerrest;

/**
 * Created by Gigabyte on 1/29/2018.
 */
public interface IDeviceGUID {

    public String getGUID() throws Exception;
    public String getPassword(String deviceGUID);
}
