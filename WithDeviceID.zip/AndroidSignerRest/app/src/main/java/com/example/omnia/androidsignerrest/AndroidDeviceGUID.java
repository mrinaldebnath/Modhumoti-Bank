package com.example.omnia.androidsignerrest;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.storage.StorageManager;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.telephony.TelephonyManager;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStreamWriter;

/**
 * Created by Gigabyte on 1/29/2018.
 */
public class AndroidDeviceGUID extends AppCompatActivity implements IDeviceGUID {
    MurmurHash hash64;
    String GUID;

    public AndroidDeviceGUID(String GUID) {
        this.GUID = GUID;
    }

    public String getGUID() throws Exception {
        hash64 = new MurmurHash();


        /*int MY_PERMISSIONS_READ_PHONE_STATE=0;
// Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission((Activity)this,
                Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {

            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale((Activity)this,
                    Manifest.permission.READ_PHONE_STATE)) {

                // Show an expanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.

            } else {

                // No explanation needed, we can request the permission.

                ActivityCompat.requestPermissions((Activity)this,
                        new String[]{Manifest.permission.READ_PHONE_STATE},
                        MY_PERMISSIONS_READ_PHONE_STATE);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        }*/


        // Code For IMEI AND IMSI NUMBER

        /*String serviceName = Context.TELEPHONY_SERVICE;
        TelephonyManager m_telephonyManager = (TelephonyManager) getSystemService(serviceName);
        String IMEI, IMSI;
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return "";
        }
        IMEI = m_telephonyManager.getDeviceId();
        IMSI = m_telephonyManager.getSubscriberId();*/

        try
        {
            FileOutputStream fileout=new FileOutputStream(new File("/data/data/com.example.omnia.androidsignerrest/mytextfile.txt"));
            OutputStreamWriter outputWriter=new OutputStreamWriter(fileout);
            outputWriter.write(GUID);
            outputWriter.close();
            fileout.close();

        }
        catch (Exception e)
        {

        }

        return Long.toHexString(hash64.hash64(GUID));

    }

    @Override
    public String getPassword(String deviceGUID) {
        return Long.toHexString(hash64.hash64(deviceGUID));
    }
}
