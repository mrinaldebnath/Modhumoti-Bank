package com.example.omnia.androidsignerrest;

import android.os.AsyncTask;
import android.util.Log;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import cz.msebera.android.httpclient.HttpResponse;
import cz.msebera.android.httpclient.client.HttpClient;
import cz.msebera.android.httpclient.client.methods.HttpPost;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.impl.client.DefaultHttpClient;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

public class HitRestAsynchronous extends AsyncTask<String, String, String> {

    AndroidDeviceGUID androidDeviceID;
    MainActivity main;
    String MobileNo;
    String DeviceGUID;

    public HitRestAsynchronous(String mNo,String m_deviceId,String m_wlanMacAdd,MainActivity m)
    {
        MobileNo=mNo;
        androidDeviceID=new AndroidDeviceGUID(m_deviceId+" "+m_wlanMacAdd);
        main=m;
    }

	@Override
	protected String doInBackground(String... params) {

        // Create a connection to the jabber.org server.
        return postLoginData();
	}

	@Override
	protected void onPostExecute(String result) {

	}

    public String postLoginData() {
        // Create a new HttpClient and Post Header
        HttpClient httpclient = new DefaultHttpClient();

        /* login.php returns true if username and password is equal to saranga */
        HttpPost httppost = new HttpPost("http://192.168.4.192:8070/register");

        try {
            // Add user name and password

            androidDeviceID.runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    try {
                        DeviceGUID=androidDeviceID.getGUID();
                    } catch (Exception e) {
                        e.printStackTrace();
                        putErrorMessageOnScreen(e.getMessage().toString());
                    }
                }

            });

            SignerRequest signerRequest=new SignerRequest("testID",MobileNo,"");

            Gson gson = new Gson();
            String json = gson.toJson(signerRequest);

            StringEntity se = new StringEntity(json);
            se.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));

            httppost.setEntity(se);

            // Execute HTTP Post Request
            Log.w("SENCIDE", "Execute HTTP Post Request");
            HttpResponse response = httpclient.execute(httppost);

            String str = inputStreamToString(response.getEntity().getContent()).toString();

            SignerResponse signerResponse = gson.fromJson(str, SignerResponse.class);
            Log.w("Status: ", signerResponse.Status);
            Log.w("Message: ", signerResponse.Message);


        } catch (Exception e) {
            putErrorMessageOnScreen(e.getMessage().toString());
        }
        return "";
    }

    private StringBuilder inputStreamToString(InputStream is) {
        String line = "";
        StringBuilder total = new StringBuilder();
        // Wrap a BufferedReader around the InputStream
        BufferedReader rd = new BufferedReader(new InputStreamReader(is));
        // Read response until the end
        try {
            while ((line = rd.readLine()) != null) {
                total.append(line);
            }
        } catch (IOException e) {
            putErrorMessageOnScreen(e.getMessage().toString());
            return new StringBuilder(e.getMessage().toString());
        }
        // Return full string
        return total;
    }
    
    public void putErrorMessageOnScreen(String message)
    {
        final String tempMessage=message; 
        main.runOnUiThread(new Runnable() {

            @Override
            public void run() {
                try {
                    main.putErrorMessageOnScreen(tempMessage);
                } catch (Exception e) {
                    putErrorMessageOnScreen(e.getMessage().toString());
                }
            }

        });
    }

}
